package exam;

public class TestPrint {
    public static void main(String[] args) {
        System.out.println(Mathx.fibonacci(-1));
    }
}
